<?php

    require_once(__DIR__."/../modelos/tipoUsuario.php");
    require_once(__DIR__."/../modelos/usuario.php");
    require_once(__DIR__."/../modelos/marca.php");
    require_once(__DIR__."/../modelos/venta.php");
    require_once(__DIR__."/../modelos/producto.php");
    require_once(__DIR__."/../modelos/categoria.php");
    require_once(__DIR__."/../modelos/carrito.php");

?>