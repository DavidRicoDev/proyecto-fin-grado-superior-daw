<?php

    require_once(__DIR__."/../controladores/controlador-tipoUsuarios.php");
    require_once(__DIR__."/../controladores/controlador-usuarios.php");
    require_once(__DIR__."/../controladores/controlador-marcas.php");
    require_once(__DIR__."/../controladores/controlador-ventas.php");
    require_once(__DIR__."/../controladores/controlador-productos.php");
    require_once(__DIR__."/../controladores/controlador-categorias.php");
    require_once(__DIR__."/../controladores/controlador-carrito.php");

?>