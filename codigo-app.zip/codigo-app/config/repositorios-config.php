<?php

    require_once(__DIR__."/../modelos/repositorios/conexion.php");
    require_once(__DIR__."/../modelos/repositorios/repositorio-tipoUsuarios.php");
    require_once(__DIR__."/../modelos/repositorios/repositorio-usuarios.php");
    require_once(__DIR__."/../modelos/repositorios/repositorio-marcas.php");
    require_once(__DIR__."/../modelos/repositorios/repositorio-ventas.php");
    require_once(__DIR__."/../modelos/repositorios/repositorio-productos.php");
    require_once(__DIR__."/../modelos/repositorios/repositorio-categorias.php");

?>