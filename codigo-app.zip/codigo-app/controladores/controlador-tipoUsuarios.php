<?php

// Incluir repositorios
require_once(__DIR__."/../config/repositorios-config.php");

class ControladorTipoUsuarios {

    // Variables
    private $repositorioTipoUsuarios;
    
    // Constructor
    public function __construct() {
        // Crear repositorio de tipos de usuario
        $this->repositorioTipoUsuarios = new RepositorioTipoUsuarios();
    }

    // Funcion que obtiene un tipo de usuario por su id
    function obtenerTipoUsuario($nombre) {
        return $this->repositorioTipoUsuarios->getTipoUsuario($nombre);
    }

    // Funcion que obtiene todos los tipos de usuario
    function obtenerTipoUsuarios() {
        return $this->repositorioTipoUsuarios->getTipoUsuarios();
    }
}
?>