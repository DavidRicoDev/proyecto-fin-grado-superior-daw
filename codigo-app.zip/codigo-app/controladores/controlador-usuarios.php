<?php

// Incluir repositorios
require_once(__DIR__."/../config/repositorios-config.php");

class ControladorUsuarios {

    // Variables
    private $repositorioUsuarios;
    
    // Constructor
    public function __construct() {
        // Crear repositorio de usuarios
        $this->repositorioUsuarios = new RepositorioUsuarios();
    }

    // Funcion que obtiene un usuario por su id
    function obtenerUsuario($id) {
        return $this->repositorioUsuarios->getUsuario($id);
    }

    // Funcion que obtiene un usuario por su email y contraseña
    function obtenerUsuarioPorEmailYContrasena($email, $contrasena) {
        return $this->repositorioUsuarios->obtenerUsuarioPorEmailYContrasena($email, $contrasena);
    }

    // Funcion que obtiene todos los usuarios
    function obtenerUsuarios() {
        return $this->repositorioUsuarios->getUsuarios();
    }

    // Funcion que guarda un usuario
    function guardarUsuario($usuario, $contrasena){
        if(empty($contrasena)){
            return "Rellene el campo contraseña del formulario!";
        }
        $resultadoValidar = $this->validarUsuario($usuario);
        if($resultadoValidar == true){
            return $this->repositorioUsuarios->guardarUsuario($usuario, $contrasena);
        } else {
            throw new Exception($resultadoValidar);
        }
    }

    // Funcion que actualiza un usuario
    function actualizarUsuario($usuario){
        $resultadoValidar = $this->validarUsuario($usuario);
        if($resultadoValidar == true){
            return $this->repositorioUsuarios->actualizarUsuario($usuario);
        } else {
            throw new Exception($resultadoValidar);
        }
    }

    // Funcion que valida los campos de un usuario
    function validarUsuario($usuario){
        if(empty($usuario->getEmail())){
            return "Rellene el campo email del formulario!";
        }

        if(empty($usuario->getDni())){
            return "Rellene el campo dni del formulario!";
        }

        if(empty($usuario->getGenero())){
            return "Rellene el campo genero del formulario!";
        }

        if(empty($usuario->getNombre())){
            return "Rellene el campo nombre del formulario!";
        }

        if(empty($usuario->getApellido())){
            return "Rellene el campo apellido del formulario!";
        }

        if(empty($usuario->getFechaNacimiento())){
            return "Rellene el campo fecha de nacimiento del formulario!";
        }

        if(empty($usuario->getTelefono())){
            return "Rellene el campo telefono del formulario!";
        }

        if(empty($usuario->getProvincia())){
            return "Rellene el campo provincia del formulario!";
        }

        if(empty($usuario->getMunicipio())){
            return "Rellene el campo municipio del formulario!";
        }

        if(empty($usuario->getDireccion())){
            return "Rellene el campo direccion del formulario!";
        }

        if(empty($usuario->getCodigoPostal())){
            return "Rellene el campo codigo postal del formulario!";
        }

        return true;
    }
}
?>