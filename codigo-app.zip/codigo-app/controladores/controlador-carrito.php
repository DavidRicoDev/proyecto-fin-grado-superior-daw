<?php

// Incluir repositorios
require_once(__DIR__."/../config/repositorios-config.php");

class ControladorCarrito {

    // Constructor
    public function __construct() {}

    // Funcion que obtiene todos los productos del carrito
    function obtenerProductos() {
        return $_SESSION["carrito"]->obtenerProductos();
    }

    // Funcion que obtiene el total de productos del carrito
    function obtenerTotalProductos() {
        return $_SESSION["carrito"]->obtenerTotalProductos();
    }

    // Funcion que obtiene el precio total del carrito
    function obtenerPrecioTotal() {
        return $_SESSION["carrito"]->obtenerPrecioTotal();
    }

    // Funcion que obtiene el carrito de la sesion
    function obtenerCarrito() {
        return $_SESSION["carrito"];
    }

    // Funcion que limpia el carrito
    function limpiarCarrito() {
        $_SESSION["carrito"] = new Carrito();
    }

    // Funcion que agrega un producto al carrito
    function agregarProducto($producto) {
        // Si no existe el carrito en la sesion
        if(empty($_SESSION["carrito"])) {
            // Creamos un nuevo carrito
            $_SESSION["carrito"] = new Carrito();
        }

        // Retornamos el carrito de la sesion
        $_SESSION["carrito"]->agregarProducto($producto);
    }

    // Funcion que elimina producto del carrito
    function eliminarProducto($producto) {
        // Eliminamos el producto del carrito
        $_SESSION["carrito"]->eliminarProducto($producto);
    }
}
?>