<?php

// Incluir repositorios
require_once(__DIR__."/../config/repositorios-config.php");

class ControladorCategorias {

    // Variables
    private $repositorioCategorias;
    
    // Constructor
    public function __construct() {
        // Crear repositorio de categorias
        $this->repositorioCategorias = new RepositorioCategorias();
    }

    // Funcion que obtiene una categoria por su id
    function obtenerCategoria($id) {
        return $this->repositorioCategorias->getCategoria($id);
    }

    // Funcion que obtiene todas las categorias
    function obtenerCategorias() {
        return $this->repositorioCategorias->getCategorias();
    }
}
?>