<?php

// Incluir repositorios
require_once(__DIR__."/../config/repositorios-config.php");

class ControladorMarcas {
    
    // Variables
    private $repositorioMarcas;
    
    // Constructor
    public function __construct() {
        // Crear repositorio de marcas
        $this->repositorioMarcas = new RepositorioMarcas();
    }

    // Funcion que obtiene una marca por su id
    function obtenerMarca($id) {
        return $this->repositorioMarcas->getMarca($id);
    }

    // Funcion que obtiene todas las marcas de base de datos
    function obtenerMarcas() {
        return $this->repositorioMarcas->getMarcas();
    }

    // Funcion que guarda una marca
    function guardarMarca($marca){
        $resultadoValidar = $this->validarMarca($marca);
        if($resultadoValidar == true){
            return $this->repositorioMarcas->guardarMarca($marca);
        } else {
            throw new Exception($resultadoValidar);
        }
    }

    // Funcion que actualiza una marca
    function actualizarMarca($marca){
        $resultadoValidar = $this->validarMarca($marca);
        if($resultadoValidar == true){
            return $this->repositorioMarcas->actualizarMarca($marca);
        } else {
            throw new Exception($resultadoValidar);
        }
    }

    // Funcion que valida los campos de una marca
    function validarMarca($marca){
        if(empty($marca->getNombre())){
            return "Rellene el campo nombre del formulario!";
        }

        if(empty($marca->getEmail())){
            return "Rellene el campo email del formulario!";
        }
        return true;
    }
}
?>