<?php

// Incluir repositorios
require_once(__DIR__."/../config/repositorios-config.php");

class ControladorVentas {

    // Variables
    private $repositorioVentas;    
    private $repositorioProductos;
    
    // Constructor
    public function __construct() {
        // Crear repositorio de ventas
        $this->repositorioVentas = new RepositorioVentas();
        // Crear repositorio de productos
        $this->repositorioProductos = new RepositorioProductos();
    }

    // Funcion que obtiene una venta por su id
    function obtenerVenta($id) {
        return $this->repositorioVentas->getVenta($id);
    }

    // Funcion que obtiene las ventas
    function obtenerVentas() {
        return $this->repositorioVentas->getVentas();
    }

    // Funcion que obtiene las venta de un usuario por su id de usuario
    function obtenerVentasPorIdUsuario($idUsuario) {
        return $this->repositorioVentas->getVentasPorIdUsuario($idUsuario);
    }

    // Funcion que finaliza una venta
    function finalizarVenta($idUsuario, $carrito){
       // Insertar venta
       $venta = new Venta(null, $idUsuario, $carrito->obtenerTotalProductos(), $carrito->obtenerPrecioTotal(), null);
       $venta = $this->repositorioVentas->guardarVenta($venta);

       // Insertar en ventasProductos
       foreach($carrito->obtenerProductos() as $producto){
            $resultadoValidar = $this->repositorioProductos->validarStock($producto->getId());
            if($resultadoValidar == true){
                $this->repositorioVentas->guardarVentaProducto($venta->getId(), $producto->getId());
                $this->repositorioProductos->decrementarStock($producto->getId());
            }
       }
       return true;
    }

    // Funcion que guarda los productos de una venta
    function obtenerProductosVenta($idVenta){
        $idProductos = $this->repositorioVentas->obtenerProductosVenta($idVenta);
        $productos = array(); 
        foreach($idProductos as $idProducto){
            $producto = $this->repositorioProductos->getProducto($idProducto);
            array_push($productos, $producto);
        }
        return $productos;
    }
}
?>
