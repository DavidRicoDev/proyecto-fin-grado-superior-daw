<?php

// Incluir repositorios
require_once(__DIR__."/../config/repositorios-config.php");

class ControladorProductos {

    // Variables
    private $repositorioProductos;
    
    // Constructor
    public function __construct() {
        // Crear repositorio de productos
        $this->repositorioProductos = new RepositorioProductos();
    }

    // Funcion que obtiene un producto por su id
    function obtenerProducto($id) {
        return $this->repositorioProductos->getProducto($id);
    }

    // Funcion que obtiene todos los productos
    function obtenerProductos() {
        return $this->repositorioProductos->getProductos();
    }

    // Funcion que guarda un producto
    function guardarProducto($producto){
        $resultadoValidar = $this->validarProducto($producto);
        if($resultadoValidar == true){
            return $this->repositorioProductos->guardarProducto($producto);
        } else {
            throw new Exception($resultadoValidar);
        }
    }

    // Funcion que actualiza un producto
    function actualizarProducto($producto){
        $resultadoValidar = $this->validarProducto($producto);
        if($resultadoValidar == true){
            return $this->repositorioProductos->actualizarProducto($producto);
        } else {
            throw new Exception($resultadoValidar);
        }
    }

    // Funcion que valida los campos de un producto
    function validarProducto($producto){
        if(empty($producto->getNombre())){
            return "Rellene el campo nombre del formulario!";
        }

        if(empty($producto->getCategoria())){
            return "Rellene el campo categoria del formulario!";
        }

        if(empty($producto->getMarca())){
            return "Rellene el campo marca del formulario!";
        }

        if(empty($producto->getStock())){
            return "Rellene el campo stock del formulario!";
        }

        if(empty($producto->getPrecio())){
            return "Rellene el campo precio del formulario!";
        }

        return true;
    }
}
?>