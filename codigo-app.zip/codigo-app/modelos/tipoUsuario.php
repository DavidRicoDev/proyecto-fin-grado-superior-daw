<?php

class TipoUsuario{

    // Variables
    private $nombre;

    // Constructor
    public function __construct($nombre){
        $this->nombre = $nombre;
    }

    // Metodos getter
    function getNombre(){
        return $this->nombre;
    }
}

?>