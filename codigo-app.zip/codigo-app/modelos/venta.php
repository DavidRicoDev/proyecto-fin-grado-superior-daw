<?php

class Venta{

    // Variables
    private $id;
    private $idUsuario;
    private $totalProductos;
    private $precioTotal;
    private $fecha;

    // Constructor
    public function __construct($id, $idUsuario, $totalProductos, $precioTotal, $fecha){
        $this->id = $id;
        $this->idUsuario = $idUsuario;
        $this->totalProductos = $totalProductos;
        $this->precioTotal = $precioTotal;
        $this->fecha = $fecha;
    }

    // Metodos getter
    function getId(){
        return $this->id;
    }

    function getIdUsuario(){
        return $this->idUsuario;
    }

    function getTotalProductos(){
        return $this->totalProductos;
    }

    function getPrecioTotal(){
        return $this->precioTotal;
    }

    function getFecha(){
        return $this->fecha;
    }
}

?>