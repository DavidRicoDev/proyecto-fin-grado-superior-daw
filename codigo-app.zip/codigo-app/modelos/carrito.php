<?php

class Carrito {

    // Variables
    private $productos = array();
    private $totalProductos;
    private $precioTotal;

    // Constructor
    public function __construct(){
        $this->productos = array();
        $this->totalProductos = 0;
        $this->precioTotal = 0;
    }

    // Funcion que obtiene todos los productos del carrito
    function obtenerProductos() {
        return $this->productos;
    }

    // Funcion que obtiene el total de productos del carrito
    function obtenerTotalProductos() {
        return $this->totalProductos;
    }

    // Funcion que obtiene el precio total del carrito
    function obtenerPrecioTotal() {
        return $this->precioTotal;
    }

    // Funcion que agrega un producto al carrito
    function agregarProducto($producto) {
        // Agregar producto al carrito
        array_push($this->productos, $producto);
        // Actualizar total de productos en el carrito
        $this->totalProductos = $this->totalProductos + 1;
        // Actualizar precio total del carrito
        $this->precioTotal = $this->precioTotal + $producto->getPrecio();
    }

    // Funcion que elimina producto del carrito
    function eliminarProducto($producto) {
        // Obtener indice del producto en el carrito
        $clave = array_search($producto, $this->productos);
        // Eliminar producto al carrito
        array_splice($this->productos, $clave, 1);
        // Actualizar total de productos en el carrito
        $this->totalProductos = $this->totalProductos - 1;
        // Actualizar precio total del carrito
        $this->precioTotal = $this->precioTotal - $producto->getPrecio();
    }
}