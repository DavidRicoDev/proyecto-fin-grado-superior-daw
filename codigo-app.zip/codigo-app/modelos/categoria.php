<?php

class Categoria {

    // Variables
    private $id;
    private $nombre;

    // Constructor
    public function __construct($id, $nombre){
        $this->id = $id;
        $this->nombre = $nombre;
    }

    // Metodos getter
    function getId(){
        return $this->id;
    }

    function getNombre(){
        return $this->nombre;
    }
}