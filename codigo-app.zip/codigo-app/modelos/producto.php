<?php

class Producto{

    // Variables
    private $id;
    private $nombre;
    private $marca;
    private $categoria;
    private $imagen;
    private $precio;
    private $stock;

    // Constructor
    public function __construct($id, $nombre, $categoria, $marca, $imagen, $precio, $stock) {
        $this->id = $id;
        $this->categoria = $categoria;
        $this->marca = $marca;
        $this->nombre = $nombre;
        $this->imagen = $imagen;
        $this->stock = $stock;
        $this->precio = $precio;
    }

    // Metodos getter
    function getId(){
        return $this->id;
    }
    function getCategoria(){
        return $this->categoria;
    }
    function getMarca(){
        return $this->marca;
    }

    function getNombre(){
        return $this->nombre;
    }

    function getImagen(){
        return $this->imagen;
    }
    function getStock(){
        return $this->stock;
    }

    function getPrecio(){
        return $this->precio;
    }

    // Metodos setter
    function setStock($stock){
        $this->stock = $stock;
    }

}

?>