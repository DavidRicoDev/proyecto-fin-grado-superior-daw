<?php

class Marca {

    // Variables
    private $id;
    private $nombre;
    private $email;

    // Constructor
    public function __construct($id, $nombre, $email){
        $this->id = $id;
        $this->nombre = $nombre;
        $this->email = $email;
    }

    // Metodos getter
    function getId(){
        return $this->id;
    }

    function getNombre(){
        return $this->nombre;
    }

    function getEmail(){
        return $this->email;
    }
}

?>