<?php

class Usuario{

    // Variables
    private $id;
    private $tipoUsuario;
    private $email;
    private $dni;
    private $genero;
    private $nombre;
    private $apellido;
    private $fechaNacimiento;
    private $telefono;
    private $provincia;
    private $municipio;
    private $direccion;
    private $codigoPostal;

    // Constructor
    public function __construct($id, $tipoUsuario, $email, $dni, $genero, $nombre, $apellido, $fechaNacimiento, $telefono, $provincia, $municipio, $direccion, $codigoPostal){
        $this->id = $id;
        $this->tipoUsuario = $tipoUsuario;
        $this->email = $email;
        $this->dni = $dni;
        $this->genero = $genero;
        $this->nombre = $nombre;
        $this->fechaNacimiento = $fechaNacimiento;
        $this->apellido = $apellido;
        $this->telefono = $telefono;
        $this->provincia = $provincia;
        $this->municipio = $municipio;
        $this->direccion = $direccion;
        $this->codigoPostal = $codigoPostal;

    }

    // Metodos getter
    function getId(){
        return $this->id;
    }

    function getTipoUsuario(){
        return $this->tipoUsuario;
    }

    function getEmail(){
        return $this->email;
    }

    function getDni(){
        return $this->dni;
    }

    function getGenero(){
        return $this->genero;
    }
    function getNombre(){
        return $this->nombre;
    }

    function getApellido(){
        return $this->apellido;
    }
    
    function getFechaNacimiento(){
        return $this->fechaNacimiento;
    }

    function getTelefono(){
        return $this->telefono;
    }
    function getProvincia(){
        return $this->provincia;
    }

    function getMunicipio(){
        return $this->municipio;
    }

    function getDireccion(){
        return $this->direccion;
    }

    function getCodigoPostal(){
        return $this->codigoPostal;
    }

}

?>