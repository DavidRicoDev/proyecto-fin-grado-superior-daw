<?php 

class RepositorioBase {

	// Variables
    private $host;
    private $user;
    private $pass;
    private $baseDatos;

	// Constructor
    public function __construct(){
        $this->host = "localhost";
        $this->user = "root";
        $this->pass = "";
        $this->baseDatos = "sportproject";
   	}

   	// funcion para conectar a base de datos
	function crearConexion() {
		// Crear conexion a base de datos
		$conexion = mysqli_connect($this->host, $this->user, $this->pass, $this->baseDatos);

		// Comprobar conexion
		if ($conexion->connect_error) {
  			die("Conexión fallida: " . $conexion->connect_error);
		}

		// Retornar conexion
		return $conexion;
	}

	// funcion para cerrar la conexion a base de datos
	function cerrarConexion($conexion) {
		// Cerrar conexion a base de datos
		mysqli_close($conexion);
	}
}

?>