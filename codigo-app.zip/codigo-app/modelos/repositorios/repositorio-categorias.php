<?php

// Incluir modelos
require_once(__DIR__."/../../config/modelos-config.php");

class RepositorioCategorias extends RepositorioBase {

    // Constructor
    public function __construct(){
       parent::__construct();
    }

    // Funcion que obtiene una categoria de base de datos por su id
	function getCategoria($id) {
	    // Crear query para obtener lista de categorias
        $sql = "SELECT * FROM categorias WHERE id_categoria='".$id."'";

		// Crear conexion a base de datos
		$conexion = $this->crearConexion();

		// Realizar consulta
		$result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

		// Cerramos la conexión ya que no la necesitamos más
		$this->cerrarConexion($conexion);
        
        // Lanzar excepcion si se produjo un error.0
        if($error_message != "") {
            throw new Exception ("Error al recuperar la categoria:".$error_message);
        }

       // Comprobar que se ha obtenido un único resultado
        if(mysqli_num_rows($result) == 1) {
            // Obtenemos el único resultado de la consulta
            $row = mysqli_fetch_assoc($result);
            // Retornamos la categoria
            return new Categoria($row["id_categoria"], $row["nombre"]);
        }
    }

    // Funcion que obtiene todas las categorias de base de datos
    function getCategorias() {

        // Crear query para obtener lista de categorias
        $sql = "SELECT * FROM categorias";

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al recuperar las categorias:".$error_message);
        }

        // Comprobar que se han obtenido resultados en el listado de categorias
        $categorias = array();
        $totalCategorias = mysqli_num_rows($result);
        if($totalCategorias > 0) {

            // Obtenemos cada fila
           for($i = 0; $i < $totalCategorias; $i++ ) {
                $row = mysqli_fetch_assoc($result);
                $categoria = new Categoria($row["id_categoria"], $row["nombre"]);
                $categorias[$i] = $categoria;
            }
        }

        // Retornamos el listado de categorias
        return $categorias;
    }
}
?>