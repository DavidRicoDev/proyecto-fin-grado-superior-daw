<?php

// Incluir modelos
require_once(__DIR__."/../../config/modelos-config.php");

class RepositorioMarcas extends RepositorioBase {

    // Constructor
    public function __construct(){
       parent::__construct();
    }

    // Funcion que obtiene una marca de base de datos por su id
	function getMarca($id) {
	    // Crear query para obtener lista de marcas
        $sql = "SELECT * FROM marcas WHERE id_marca='".$id."'";

		// Crear conexion a base de datos
		$conexion = $this->crearConexion();

		// Realizar consulta
		$result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

		// Cerramos la conexión ya que no la necesitamos más
		$this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al recuperar los  productos:".$error_message);
        }

       // Comprobar que se ha obtenido un único resultado
        if(mysqli_num_rows($result) == 1) {
            // Obtenemos el único resultado de la consulta
            $row = mysqli_fetch_assoc($result);
            // Retornamos la marca
            return new Marca($row["id_marca"], $row["nombre"], $row["email"]);
        }
    }

    // Funcion que obtiene todas las marcas de base de datos
    function getMarcas() {
        // Crear query para obtener lista de marcas
        $sql = "SELECT * FROM marcas";

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al recuperar las marcas:".$error_message);
        }

        // Comprobar que se han obtenido resultados en el listado de marcas
        $marcas = array();
        $totalMarcas = mysqli_num_rows($result);
        if($totalMarcas > 0) {

            // Obtenemos cada fila
           for($i = 0; $i < $totalMarcas; $i++ ) {
                $row = mysqli_fetch_assoc($result);
                $marca = new Marca($row["id_marca"], $row["nombre"], $row["email"]);
                $marcas[$i] = $marca;
            }
        }

        // Retornamos el listado de marcas
        return $marcas;
    }

    // Funcion que guarda una marca en base de datos
    function guardarMarca($marca) {
        // Crear query para guardar marca
        $sql = "INSERT INTO marcas (nombre, email) VALUES ('".$marca->getNombre()."','".$marca->getEmail()."')";

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            // Cerramos la conexión ya que no la necesitamos más
            $this->cerrarConexion($conexion);
            throw new Exception ("Error al guardar la marca:".$error_message);
        }

        // Crear query que obtiene la ultima marca insertada en base de datos
        $sql = "SELECT * FROM MARCAS ORDER BY id_marca DESC LIMIT 1";

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al guardar la marca:".$error_message);
        }

        // Comprobar que se ha obtenido un único resultado
        if(mysqli_num_rows($result) == 1) {
            // Obtenemos el único resultado de la consulta
            $row = mysqli_fetch_assoc($result);
            // Retornamos la marca
            return new Marca($row["id_marca"], $row["nombre"], $row["email"]);
        }
    }
    
    // Funcion que actualiza una marca en base de datos
    function actualizarMarca($marca) {
        // Crear query para guardar marca
        $sql = "UPDATE MARCAS SET nombre = '".$marca->getNombre()."', email = '".$marca->getEmail()."' WHERE id_marca = ".$marca->getId();

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);   

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ('Error al actualizar la marca:'.$error_message);
        }

        // Retornar la marca
        return $marca;
    }
}
?>