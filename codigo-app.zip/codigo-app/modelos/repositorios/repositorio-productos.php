<?php

// Incluir modelos
require_once(__DIR__."/../../config/modelos-config.php");

class RepositorioProductos extends RepositorioBase {

    // Constructor
    public function __construct(){
       parent::__construct();
    }

    // Funcion que obtiene un producto de base de datos por su id
	function getProducto($id) {
        // Crear query para obtener lista de productos
        $sql = "SELECT * FROM productos WHERE id_producto='".$id."'";

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al recuperar el producto:".$error_message);
        }

        // Comprobar que se ha obtenido un único resultado
        if(mysqli_num_rows($result) == 1) {
            // Obtenemos el único resultado de la consulta
            $row = mysqli_fetch_assoc($result);
            // Retornamos el producto
            return new Producto($row["id_producto"], $row["nombre"], $row["categoria"], $row["marca"], $row["imagen"], $row["precio"], $row["stock"]);
        }
    }

    // Funcion que obtiene todos los productos de base de datos
    function getProductos() {
        // Crear query para obtener lista de productos
        $sql = "SELECT * FROM productos";

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al recuperar los productos:".$error_message);
        }

        // Comprobar que se han obtenido resultados en el listado de productos
        $productos = array();
        $totalProductos = mysqli_num_rows($result);
        if($totalProductos > 0) {

            // Obtenemos cada fila
           for($i = 0; $i < $totalProductos; $i++ ){
                $row = mysqli_fetch_assoc($result);
                $producto = new Producto($row["id_producto"], $row["nombre"], $row["categoria"], $row["marca"], $row["imagen"], $row["precio"], $row["stock"]);
                $productos[$i] = $producto;
            }
        }

        // Retornamos el listado de productos
        return $productos;
    }

    // Funcion que guarda un producto en base de datos
    function guardarProducto($producto){
        // Crear query para guardar producto
        $sql = "INSERT INTO PRODUCTOS (nombre, categoria, marca, imagen, precio, stock) VALUES ('".$producto->getNombre()."',".$producto->getCategoria().",".$producto->getMarca().",'".$producto->getImagen()."',".$producto->getPrecio().",".$producto->getStock().")";

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            // Cerramos la conexión ya que no la necesitamos más
            $this->cerrarConexion($conexion);
            throw new Exception ("Error al guardar el producto:".$error_message);
        }

        // Crear query que obtiene el ultimo producto insertado en base de datos
        $sql = "SELECT * FROM PRODUCTOS ORDER BY id_producto DESC LIMIT 1";

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al guardar el producto:".$error_message);
        }

        // Comprobar que se ha obtenido un único resultado
        if(mysqli_num_rows($result) == 1) {
            // Obtenemos el único resultado de la consulta
            $row = mysqli_fetch_assoc($result);
            // Retornamos el producto
            return new Producto($row["id_producto"], $row["nombre"], $row["categoria"], $row["marca"], $row["imagen"], $row["precio"], $row["stock"]);
        }
    }

    // Funcion que actualiza un producto en base de datos
    function actualizarProducto($producto){
        // Crear query para actualizar producto
        $sql = "UPDATE PRODUCTOS SET nombre='".$producto->getNombre()."', categoria=".$producto->getCategoria().", marca=".$producto->getMarca().", precio=".$producto->getPrecio().", stock=".$producto->getStock()." WHERE id_producto=".$producto->getId(); 

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al actualizar el producto:".$error_message);
        }

        // Retornamos el producto
        return $producto;
    }

    // Funcion que decrementa el stock de un producto en base de datos por su id
    function decrementarStock($idProducto){
        // Obtener producto
        $producto = $this->getProducto($idProducto);
        // Decrementar stock
        $nuevoStock = $producto->getStock() - 1;
        // Asignar el nuevo stock
        $producto->setStock($nuevoStock);
        // Actualizar producto
        $this->actualizarProducto($producto);
    }

    // Funcion que valida el stock de un producto en base de datos por su id
    function validarStock($idProducto){
        // Obtener producto
        $producto = $this->getProducto($idProducto);
        // Si el stock es mayor que 0 retornamos true, en caso contrario retornamos false
        return $producto->getStock() > 0;
    }
    
}
?>