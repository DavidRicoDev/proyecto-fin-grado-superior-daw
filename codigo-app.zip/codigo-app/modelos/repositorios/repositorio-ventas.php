<?php

// Incluir modelos
require_once(__DIR__."/../../config/modelos-config.php");

class RepositorioVentas extends RepositorioBase {

    // Constructor
    public function __construct(){
       parent::__construct();
    }

    // Funcion que obtiene una venta de base de datos por su id
	function getVenta($id) {
		// Crear query para obtener lista de ventas
        $sql = "SELECT * FROM ventas WHERE id_venta='".$id."'";

		// Crear conexion a base de datos
		$conexion = $this->crearConexion();

		// Realizar consulta
		$result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

		// Cerramos la conexión ya que no la necesitamos más
		$this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al recuperar las ventas:".$error_message);
        }

		// Comprobar que se ha obtenido un único resultado
        if(mysqli_num_rows($result) == 1) {
            // Obtenemos el único resultado de la consulta
            $row = mysqli_fetch_assoc($result);
            // Retornamos la venta
            return new Venta($row["id_venta"], $row["id_usuario"], $row["total_productos"],$row["precio_total"], $row["fecha"]);
        }
    }

    // Funcion que obtiene todas las venta de base de datos
    function getVentas() {

        // Crear query para obtener lista de ventas
        $sql = "SELECT * FROM ventas";

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al recuperar las ventas:".$error_message);
        }

        // Comprobar que se han obtenido resultados en el listado de ventas
        $ventas = array();
        $totalVentas = mysqli_num_rows($result);
        if($totalVentas > 0) {

            // Obtenemos cada fila
           for($i = 0; $i < $totalVentas; $i++ ){
                $row = mysqli_fetch_assoc($result);
                $venta = new Venta($row["id_venta"], $row["id_usuario"], $row["total_productos"],$row["precio_total"], $row["fecha"]);
                $ventas[$i] = $venta;
            }
        }

		// Retornamos el resultado de la consulta
		return $ventas;
	}

    // Funcion que obtiene las venta de un usuario de base de datos por su id de usuario
    function getVentasPorIdUsuario($idUsuario) {

        // Crear query para obtener lista de ventas
        $sql = "SELECT * FROM ventas WHERE id_usuario = ".$idUsuario;

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al recuperar las ventas:".$error_message);
        }

        // Comprobar que se han obtenido resultados en el listado de ventas
        $ventas = array();
        $totalVentas = mysqli_num_rows($result);
        if($totalVentas > 0) {

            // Obtenemos cada fila
           for($i = 0; $i < $totalVentas; $i++ ){
                $row = mysqli_fetch_assoc($result);
                $venta = new Venta($row["id_venta"], $row["id_usuario"], $row["total_productos"],$row["precio_total"], $row["fecha"]);
                $ventas[$i] = $venta;
            }
        }

		// Retornamos el resultado de la consulta
		return $ventas;
	}

    // Funcion que guarda una venta en base de datos
    function guardarVenta($venta){
        // Crear query para guardar venta
        $sql = "INSERT INTO VENTAS (id_usuario, total_productos, precio_total, fecha) VALUES (".$venta->getIdUsuario().",'".$venta->getTotalProductos()."','".$venta->getPrecioTotal()."', CURRENT_TIMESTAMP)";

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
             // Cerramos la conexión ya que no la necesitamos más
            $this->cerrarConexion($conexion);
            throw new Exception ("Error al guardar la venta:".$error_message);
        }

        $sql = "SELECT * FROM VENTAS ORDER BY id_venta DESC LIMIT 1";
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

         // Cerramos la conexión ya que no la necesitamos más
         $this->cerrarConexion($conexion);

         // Lanzar excepcion si se produjo un error
         if($error_message != "") {
            throw new Exception ("Error al recuperar la venta:".$error_message);
        }

        // Comprobar que se ha obtenido un único resultado
        if(mysqli_num_rows($result) == 1) {
            // Obtenemos el único resultado de la consulta
            $row = mysqli_fetch_assoc($result);
            // Retornamos la venta
            return new Venta($row["id_venta"], $row["id_usuario"], $row["total_productos"],$row["precio_total"], $row["fecha"]);
        }

    }

    // Funcion que guarda los productos de una venta en base de datos
    function guardarVentaProducto($idVenta, $idProducto){
        // Crear query para insertar el producto y la venta en la tabla ventas_producto
        $sql = "INSERT INTO VENTAS_PRODUCTOS (id_venta, id_producto) VALUES (".$idVenta.",".$idProducto.")";

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al guardar el producto de la venta:".$error_message);
        }
    }

    // Funcion que obtiene los ids de productos de una venta en base de datos por su id de venta
    function obtenerProductosVenta($idVenta){
        // Crear query para obtener el id de los productos de una venta por su id en la tabla ventas_producto
        $sql = "SELECT * FROM VENTAS_PRODUCTOS WHERE id_venta = ".$idVenta;        

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al obtener los productos de la venta:".$error_message);
        }

        $idProductos = array();
        // Comprobar que se ha obtenido un único resultado
        $totalProductos = mysqli_num_rows($result);
        if($totalProductos > 0) {
            // Obtenemos cada fila
           for($i = 0; $i < $totalProductos; $i++ ){
                $row = mysqli_fetch_assoc($result);
                $idProductos[$i] = $row["id_producto"];
            }
        }
        return $idProductos;
    }
}
?>