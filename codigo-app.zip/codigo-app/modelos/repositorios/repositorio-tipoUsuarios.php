<?php

// Incluir modelos
require_once(__DIR__."/../../config/modelos-config.php");

class RepositorioTipoUsuarios extends RepositorioBase {

    // Constructor
    public function __construct(){
       parent::__construct();
    }

    // Funcion que obtiene un tipo de usuario de base de datos por su id
	function getTipoUsuario($nombre) {
	    // Crear query para obtener lista de tipoUsuarios
        $sql = "SELECT * FROM tipo_usuario WHERE nombre='".$nombre."'";

		// Crear conexion a base de datos
		$conexion = $this->crearConexion();

		// Realizar consulta
		$result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

		// Cerramos la conexión ya que no la necesitamos más
		$this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al recuperar el tipo de usuario:".$error_message);
        }

       // Comprobar que se ha obtenido un único resultado
        if(mysqli_num_rows($result) == 1) {
            // Obtenemos el único resultado de la consulta
            $row = mysqli_fetch_assoc($result);
            // Retornamos el TipoUsuario
            return new TipoUsuario($row["nombre"]);
        }
    }

    // Funcion que obtiene todos los tipos de usuario de base de datos
    function getTipoUsuarios() {
        // Crear query para obtener lista de tipoUsuarios
        $sql = "SELECT * FROM tipo_usuario";

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al recuperar los tipos de usuario:".$error_message);
        }

        // Comprobar que se han obtenido resultados en el listado de tipoUsuarios
        $tipoUsuarios = array();
        $totalTipoUsuarios = mysqli_num_rows($result);
        if($totalTipoUsuarios > 0) {

            // Obtenemos cada fila
           for($i = 0; $i < $totalTipoUsuarios; $i++ ){
                $row = mysqli_fetch_assoc($result);
                $tipoUsuario = new TipoUsuario($row["nombre"]);
                $tipoUsuarios[$i] = $tipoUsuario;
            }
        }

        // Retornamos el listado de tipos de usuario
        return $tipoUsuarios;
    }
}
?>