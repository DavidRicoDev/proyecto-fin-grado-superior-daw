<?php

// Incluir modelos
require_once(__DIR__."/../../config/modelos-config.php");

class RepositorioUsuarios extends RepositorioBase {

    // Constructor
    public function __construct(){
       parent::__construct();
    }

    // Funcion que obtiene un usuario de base de datos por su id
    function getUsuario($id){
        // Crear query para obtener lista de usuarios
        $sql = "SELECT * FROM usuarios WHERE id_usuario='".$id."'";

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al obtener el usuario:".$error_message);
        }

        // Comprobar que se ha obtenido un único resultado
        if(mysqli_num_rows($result) == 1) {
            // Obtenemos el único resultado de la consulta
            $row = mysqli_fetch_assoc($result);
            // Retornamos el usuario
            return new Usuario($row["id_usuario"], $row["tipo_usuario"], $row["email"], $row["dni"], $row["genero"], $row["nombre"], $row["apellido"], $row["fecha_nacimiento"], $row["telefono"], $row["provincia"], $row["municipio"], $row["direccion"], $row["codigo_postal"]);
        }
    }

    // Funcion que obtiene un usuario de base de datos por su email y contraseña
    function obtenerUsuarioPorEmailYContrasena($email, $contrasena) {
        // Crear query para obtener lista de usuarios
        $sql = "SELECT * FROM usuarios WHERE email='".$email."' AND contrasena= '".$contrasena."'";

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error! email o contraseña incorrecto");
        }

        // Comprobar que se ha obtenido un único resultado
        if(mysqli_num_rows($result) == 1) {
            // Obtenemos el único resultado de la consulta
            $row = mysqli_fetch_assoc($result);
            // Retornamos el usuario
            return new Usuario($row["id_usuario"], $row["tipo_usuario"], $row["email"], $row["dni"], $row["genero"], $row["nombre"], $row["apellido"], $row["fecha_nacimiento"], $row["telefono"], $row["provincia"], $row["municipio"], $row["direccion"], $row["codigo_postal"]);
        }
    }

    // Funcion que obtiene todos los usuarios de base de datos
	function getUsuarios() {
		// Crear query para obtener lista de usuarios
		$sql = "SELECT * FROM usuarios";

		// Crear conexion a base de datos
		$conexion = $this->crearConexion();

		// Realizar consulta
		$result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al obtener usuarios:".$error_message);
        }

		 // Comprobar que se han obtenido resultados en el listado de usuarios
         $usuarios = array();
         $totalUsuarios = mysqli_num_rows($result);
         if($totalUsuarios > 0) {

            // Obtenemos cada fila
           for($i = 0; $i < $totalUsuarios; $i++ ){
                $row = mysqli_fetch_assoc($result);
                $usuario = new Usuario($row["id_usuario"], $row["tipo_usuario"], $row["email"], $row["dni"], $row["genero"], $row["nombre"], $row["apellido"], $row["fecha_nacimiento"], $row["telefono"], $row["provincia"], $row["municipio"], $row["direccion"], $row["codigo_postal"]);
                $usuarios[$i] = $usuario;
            }
        }

		// Retornamos el listado de usuarios
		return $usuarios;
	}

    // Funcion que guarda un usuario en base de datos
    function guardarUsuario($usuario, $contrasena){
        // Crear query para guardar el usuario
        $sql = "INSERT INTO USUARIOS (tipo_usuario, email, contrasena, dni, genero, nombre, apellido, fecha_nacimiento, telefono, provincia, municipio, direccion, codigo_postal) VALUES ('".$usuario->getTipoUsuario()."','".$usuario->getEmail()."','".$contrasena."','".$usuario->getDni()."',".$usuario->getGenero().",'".$usuario->getNombre()."','".$usuario->getApellido()."','".$usuario->getFechaNacimiento()."','".$usuario->getTelefono()."','".$usuario->getProvincia()."','".$usuario->getMunicipio()."','".$usuario->getDireccion()."','".$usuario->getCodigoPostal()."')";

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            // Cerramos la conexión ya que no la necesitamos más
            $this->cerrarConexion($conexion);
            throw new Exception ("Error al guardar el usuario:".$error_message);
        }

        // Crear query que obtiene el ultimo usuario insertado en base de datos
        $sql = "SELECT * FROM USUARIOS ORDER BY id_usuario DESC LIMIT 1";

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

         // Cerramos la conexión ya que no la necesitamos más
         $this->cerrarConexion($conexion);

         // Lanzar excepcion si se produjo un error
         if($error_message != "") {
             throw new Exception ("Error al actualizar el usuario:".$error_message);
         } 

        // Comprobar que se ha obtenido un único resultado
        if(mysqli_num_rows($result) == 1) {
            // Obtenemos el único resultado de la consulta
            $row = mysqli_fetch_assoc($result);
            // Retornamos el usuario
            return new Usuario($row["id_usuario"], $row["tipo_usuario"], $row["email"], $row["dni"],  $row["genero"], $row["nombre"], $row["apellido"], $row["fecha_nacimiento"], $row["telefono"], $row["provincia"], $row["municipio"], $row["direccion"], $row["codigo_postal"]);
        }
    }

    // Funcion que actualiza un usuario en base de datos
    function actualizarUsuario($usuario) {
        // Crear query para actualizar el usuario
        $sql = "UPDATE USUARIOS SET tipo_usuario='".$usuario->getTipoUsuario()."', email= '".$usuario->getEmail()."', dni= '".$usuario->getDni()."', genero= ".$usuario->getGenero().", nombre = '".$usuario->getNombre()."', apellido = '".$usuario->getApellido()."', fecha_nacimiento = '".$usuario->getFechaNacimiento()."', telefono = '".$usuario->getTelefono()."', provincia = '".$usuario->getProvincia()."', municipio = '".$usuario->getMunicipio()."', direccion = '".$usuario->getDireccion()."', codigo_postal = ".$usuario->getCodigoPostal()." WHERE id_usuario = ".$usuario->getId();

        // Crear conexion a base de datos
        $conexion = $this->crearConexion();

        // Realizar consulta
        $result = mysqli_query($conexion, $sql);
        $error_message = mysqli_error($conexion);

        // Cerramos la conexión ya que no la necesitamos más
        $this->cerrarConexion($conexion);

        // Lanzar excepcion si se produjo un error
        if($error_message != "") {
            throw new Exception ("Error al actualizar el usuario:".$error_message);
        }

        // Retornar el usuario
        return $usuario;
    }
}
?>