<?php

    // Incluir controladores
    require_once(__DIR__."/../config/controladores-config.php");

    // Si no existe un usuario en la sesion
    if(empty($_SESSION["usuario"])) {
        // Mostrar la pagina de login
        require_once(__DIR__."/login.php");
    } else {
        // Crear controlador de productos
        $controladorProductos = new ControladorProductos();
        // Crear controlador de marcas
        $controladorMarcas = new ControladorMarcas();
        // Crear controlador de categorias
        $controladorCategorias = new ControladorCategorias();
        // Crear controlador de carrito
        $controladorCarrito = new ControladorCarrito();

        // Obtener productos desde base de datos
        $productos = $controladorProductos->obtenerProductos();        
        // Obtener marcas desde base de datos
        $marcas = $controladorMarcas->obtenerMarcas();
        // Obtener categorias desde base de datos
        $categorias = $controladorCategorias->obtenerCategorias();
?>
        
        <form id="formularioPrincipal" name="formularioPrincipal" method="POST" class="pt-4 pb-4 col container-fluid rounded bg-light">
            <div class="row">
                <?php
                // Recorrer listado de productos
                foreach($productos as $producto) {                    
                    // Si el POST indica que se hizo click en un boton de agregar producto al carrito
                    if (isset($_POST["button-".$producto->getId()])) {
                        // Agregar producto al carrito
                        $controladorCarrito->agregarProducto($producto);
                        // Refrescar pagina actual
                        echo("<meta http-equiv='refresh' content='0'>");
                    }
                ?>
                    <div class="col-4">
                        <div class="card mb-2">

                            <?php if ($producto->getImagen() != null) { ?>
                                <img class="card-img-top" src="<?php echo "./../img/".$producto->getImagen().".jpg" ?>" alt="Img blob desde MySQL" style="height: 250px">
                            <?php } else { ?>
                                <img class="card-img-top" src="./../img/imagen.jpg" alt="Img blob desde MySQL"  style="height: 250px">
                            <?php } ?>
                            
                            <div class="card-body">
                                <div class="container-fluid">
                                    <h5 class="card-title"><?php echo $producto->getNombre() ?></h5>
                                </div>
                                <div class="container-fluid">
                                    <div class="row">
                                        <?php
                                        // Recorrer listado de marcas
                                        foreach($marcas as $marca) {
                                            // Si el id de la marca coincide con el id de la marca a la que pertenece el producto actual
                                            if ($marca->getId() == $producto->getMarca()) {
                                        ?>
                                                <p class="col-6 card-text mb-2">Marca: <?php echo $marca->getNombre() ?></p>
                                        <?php
                                                break;
                                            }
                                        }
                                        ?>

                                        <p class="col-6 text-end fw-bold card-text mb-2">Precio: <?php echo $producto->getPrecio() ?>€</p>

                                        <?php
                                        // Recorrer listado de categorias
                                        foreach($categorias as $categoria) {
                                            // Si el id de la categoria coincide con el id de la categoria a la que pertenece el producto actual
                                            if ($categoria->getId() == $producto->getCategoria()) {
                                        ?>
                                                <p class="col-12 card-text mb-2">Categoría: <?php echo $categoria->getNombre() ?></p>
                                        <?php
                                                break;
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>

                                <div class="container-fluid text-center">
                                    <?php 
                                        // Si se dispone de stock para este producto se muestra el boton para agregar al carrito
                                        if ($producto->getStock() > 0) {
                                    ?>
                                        <input type="submit" id="<?php echo "button-".$producto->getId() ?>" name="<?php echo "button-".$producto->getId() ?>" class="btn btn-primary" value="Agregar al carrito"></input>
                                    <?php 
                                        // Si no dispone de stock para este producto se muestra el boton Sin stock deshabilitado que no permite agregarlo al carrito
                                        } else {  ?>
                                        <button class="btn btn-primary" disabled>Sin stock</a>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php
                    }
                ?>
            </div>
        </form>

<?php
    }
?>