<?php
    // Incluir controladores
    require_once(__DIR__."/../config/controladores-config.php");
    // Iniciar sesion
    session_start();
    // Incluir cabecera de pagina
    require_once(__DIR__."/plantilla/cabecera.php");

    // Crear controlador de usuarios
    $controladorUsuarios = new controladorUsuarios();

    // Comprobar si hemos llegado a través del método POST
    if (!empty($_POST)) {
        //Comprobar que se han enviado todos los datos NO NULOS del formulario
        if (!empty ($_POST["email"]) 
            && !empty ($_POST["contrasena"]) 
            && !empty($_POST["dni"]) 
            && (!empty($_POST["genero"] || $_POST["genero"] == 0)) 
            && !empty($_POST["nombre"]) 
            && !empty($_POST["apellido"]) 
            && !empty($_POST["fecha_nacimiento"]) 
            && !empty($_POST["telefono"]) 
            && !empty($_POST["provincia"]) 
            && !empty($_POST["municipio"]) 
            && !empty($_POST["direccion"]) 
            && !empty($_POST["codigo_postal"])) {
            // Obtener datos desde formulario
            $tipoUsuario = "Cliente";
            $email = $_POST["email"];
            $contrasena = $_POST["contrasena"];
            $dni= $_POST["dni"];
            $genero = $_POST["genero"];
            $nombre = $_POST["nombre"];
            $apellido = $_POST["apellido"];
            $fechaNacimiento = $_POST["fecha_nacimiento"];
            $telefono = $_POST["telefono"];
            $provincia = $_POST["provincia"];
            $municipio = $_POST["municipio"];
            $direccion = $_POST["direccion"];
            $codigoPostal = $_POST["codigo_postal"];

            try{
                // Crear usuario en base de datos
                $usuario = $controladorUsuarios->guardarUsuario(new Usuario(null, $tipoUsuario, $email, $dni, $genero, $nombre, $apellido, $fechaNacimiento, $telefono, $provincia, $municipio, $direccion, $codigoPostal), $contrasena);
                // Agregar el usuario creado a la sesion
                $_SESSION["usuario"] = $usuario;
                // Redireccion a la pagina principal
                header("Location: ./..");
                exit();
            // Controlar excepciones
            } catch (Exception $e) {
                echo "
                    <div class='alert alert-danger' role='alert'>
                        ".$e->getMessage()."
                    </div>";
            }
        }
    }
    
?>

<div class="row">

    <div class="col-12 mt-3 text-center bg-light">
        <h4>Registro de usuario</h4>
    </div>
        
    <form id="formularioRegistro" name="formularioRegistro" method="POST" class="pb-3 rounded bg-light">
        <div class="row mt-2">

            <div class="col-3">
                <label class="form-label" for="email">Email</label>
                <input class="form-control" id="email" name="email" type="email" required>
            </div>

            <div class="col-3">
                <label class="form-label" for="contrasena">Contraseña</label>
                <input class="form-control" id="contrasena" name="contrasena" type="password" required>
            </div>

            <div class="col-3">
                <label class="form-label" for="dni">Dni</label>             
                <input class="form-control" id="dni" name="dni" type="text" required>
            </div>

            <div class="col-3">
                <label class="form-label" for="genero">Genero</label>            
                <select id="genero" name="genero" class="form-select" required>
                    <option selected>
                    <option value="1">Hombre</option>
                    <option value="0">Mujer</option>
                </select>
            </div>

            <div class="col-3">
                <label class="form-label" for="nombre">Nombre</label>              
                <input class="form-control" id="nombre" name="nombre" type="text" required>
            </div>

            <div class="col-3">
                <label class="form-label" for="apellido">Apellido</label>
                <input class="form-control"  id="apellido" name="apellido" type="text" required>
            </div>

            <div class="col-3">
                <label class="form-label" for="fecha_nacimiento">Fecha nacimiento</label>
                <input class="form-control"  id="fecha_nacimiento" name="fecha_nacimiento" type="date" required>
            </div>

            <div class="col-3">
                <label class="form-label" for="telefono">Telefono</label>
                <input class="form-control" id="telefono" name="telefono" type="number" required> 
            </div>

            <div class="col-3">
                <label class="form-label" for="provincia">Provincia</label>
                <input class="form-control" id="provincia" name="provincia" type="text" required> 
            </div>

            <div class="col-3">
                <label class="form-label" for="municipio">Municipio</label>
                <input class="form-control" id="municipio" name="municipio" type="text" required> 
            </div>

            <div class="col-3">
                <label class="form-label" for="direccion">Direccion</label>
                <input class="form-control" id="direccion" name="direccion" type="text" required> 
            </div>

            <div class="col-3">
                <label class="form-label" for="codigo_postal">Codigo postal</label>
                <input class="form-control" id="codigo_postal" name="codigo_postal" type="number" required> 
            </div>

            <div class="row mt-3 justify-content-around">
                <div class="col-2">
                    <button class="btn btn-secondary" type="reset">Resetear</button>
                </div>

                <div class="col-2">
                    <input class="btn btn-primary" type="submit" value="Guardar" />
                </div>
            </div>
        </div>
    </form>
</div>

<?php 
    // Incluir pie de pagina
    require_once(__DIR__."/plantilla/pie.php");
?>