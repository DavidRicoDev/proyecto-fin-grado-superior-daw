<?php
    // Incluir controladores
    require_once(__DIR__."/../config/controladores-config.php");
    // Crear controlador de usuarios
    $controladorUsuarios = new controladorUsuarios();

    // Comprobar si hemos llegado a través del método POST
    if (!empty($_POST)) {
        //Comprobar que se han enviado todos los datos NO NULOS del formulario
        if (!empty($_POST["email"]) && !empty($_POST["contrasena"])){
            // Obtener datos desde formulario
            $email = $_POST["email"];
            $contrasena = $_POST["contrasena"];

            try{
                // Obtener usuario por email y contraseña desde base de datos
                $usuario = $controladorUsuarios->obtenerUsuarioPorEmailYContrasena($email, $contrasena);
                // Si no existe el usuario
                if($usuario == null){
                    // Mostrar mensaje de error
                    echo "
                        <div class='alert alert-danger' role='alert'>
                            Usuario o contraseña no valido!!
                        </div>";
                // Si existe el usuario
                } else {
                    // Agregar el usuario a la sesion
                    $_SESSION["usuario"] = $usuario;
                    // Redireccion a la pagina principal
                    header("Location: .");
                    exit();
                }
            // Controlar excepciones
            } catch (Exception $e) {
                echo "
                    <div class='alert alert-danger' role='alert'>
                        ".$e->getMessage()."
                    </div>";
            }
        }
       
    } 

?>

<form id="formularioLogin" name="formularioLogin" method="POST">

    <div class="row mt-2 justify-content-center">

        <div class="col-4">
            <label class="form-label" for="email">Email</label>
            <input class="form-control" id="email" name="email" type="email">
        </div>
    </div>
    
    <div class="row mt-2 justify-content-center">
        <div class="col-4">
            <label class="form-label" for="contrasena">Contraseña</label>
            <input class="form-control" id="contrasena" name="contrasena" type="password">
        </div>        
    </div>

    <div class="row mt-4 justify-content-center">
        <div class="col-2 text-center">
            <button class="btn btn-secondary" type="reset">Resetear</button>
        </div>

        <div class="col-2 text-center">
            <a href="/vistas/registro.php" class="btn btn-success" >Registro</a>
        </div>
        
        <div class="col-2 text-center">
            <input class="btn btn-primary" type="submit" value="Login" />
        </div>
    </div>

</form>