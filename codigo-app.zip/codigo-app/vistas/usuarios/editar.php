<?php
    // Incluir controladores
    require_once(__DIR__."/../../config/controladores-config.php");

    // Si no existe un usuario en la sesion
    if(empty($_SESSION["usuario"])) {
        // Mostrar la pagina de login
        require_once(__DIR__."/../login.php");
    // Si el usuario activo es de tipo cliente solo puede editar sus propios datos
    } else if ($_SESSION["usuario"]->getTipoUsuario() == "Cliente"
                    && !empty($_GET["id"]) && $_GET["id"] != $_SESSION["usuario"]->getId()) {
        // Mostrar la pagina de acceso denegado
        require_once(__DIR__."/../plantilla/acceso-denegado.php");
    // Si el usuario activo es de tipo cliente no puede registrar nuevos usuarios
    } else if ($_SESSION["usuario"]->getTipoUsuario() == "Cliente" && empty($_GET["id"])) {
        // Mostrar la pagina de acceso denegado
        require_once(__DIR__."/../plantilla/acceso-denegado.php");
    } else {
        // Crear controlador de tipos de usuario
        $controladorTipoUsuario = new ControladorTipoUsuarios();
        // Crear controlador de usuarios
        $controladorUsuarios = new ControladorUsuarios();

        // Obtener tipos de usuario
        $tiposUsuario = $controladorTipoUsuario->obtenerTipoUsuarios();
        // Crear objeto que se almacenará en base de datos
        $usuario = null;

        // Si aparece el parametro id en la URL significa que es una edicion
        if (!empty($_GET["id"])) {
            // Obtenemos el usuario
            $usuario = $controladorUsuarios->obtenerUsuario($_GET["id"]);
        } 

        // Comprobar si hemos llegado a través del método POST
        if (!empty($_POST)) {
            //Comprobar que se han enviado todos los datos NO NULOS del formulario
            if ((!empty($_POST["genero"] || $_POST["genero"] == 0)) 
                && !empty($_POST["nombre"]) 
                && !empty($_POST["apellido"]) 
                && !empty($_POST["fecha_nacimiento"]) 
                && !empty($_POST["telefono"]) 
                && !empty($_POST["provincia"]) 
                && !empty($_POST["municipio"]) 
                && !empty($_POST["direccion"]) 
                && !empty($_POST["codigo_postal"])) {
                // Obtener datos desde formulario
                $genero = $_POST["genero"];
                $nombre = $_POST["nombre"];
                $apellido = $_POST["apellido"];
                $fechaNacimiento = $_POST["fecha_nacimiento"];
                $telefono = $_POST["telefono"];
                $provincia = $_POST["provincia"];
                $municipio = $_POST["municipio"];
                $direccion = $_POST["direccion"];
                $codigoPostal = $_POST["codigo_postal"];

                try{
                    // Actualizar usuario en base de datos
                    $usuario = $controladorUsuarios->actualizarUsuario(new Usuario($usuario->getId(), $usuario->getTipoUsuario(), $usuario->getEmail(), $usuario->getDni(), $genero, $nombre, $apellido, $fechaNacimiento, $telefono, $provincia, $municipio, $direccion, $codigoPostal));
                    // Mostramos el mensaje de usuario actualizado
                    echo "
                        <div class='alert alert-success' role='alert'>
                            Usuario actualizado correctamente.
                        </div>";  
                // Controlar excepciones
                } catch (Exception $e) {
                    echo "
                        <div class='alert alert-danger' role='alert'>
                            ".$e->getMessage()."
                        </div>";
                }
            }
        }
?>

        <div class="pt-3 col-12 text-center">
            <h4>Editar usuario</h4>
        </div>
                
        <form id="formularioUsuario" name="formularioUsuario" method="POST" class="pb-3">

            <div class="row mt-2">
                
                <div class="col-3">
                    <label class="form-label" for="id">Id</label>
                    <input class="form-control" id="id" name="id" type="text" value="<?php echo $usuario->getId() ?>" disabled>
                </div>

                <?php if($usuario->getTipoUsuario() == "Administrador"){ ?>
                    <div class="col-3">
                        <label class="form-label" for="tipoUsuario">Tipo de usuario</label>
                        <select id="tipoUsuario" name="tipoUsuario" class="form-select" required>
                            <?php if($usuario->getTipoUsuario() == "Administrador"){ ?>
                                <option value="1" selected>Administrador</option>
                            <?php } else { ?>
                                <option value="1">Administrador</option>
                            <?php } ?>

                            <?php if($usuario->getTipoUsuario() == "Cliente"){ ?>
                                <option value="0" selected>Cliente</option>
                            <?php } else { ?>
                                <option value="0">Cliente</option>
                            <?php } ?>
                        </select>                   
                    </div>
                <?php } ?>

                <div class="col-3">
                    <label class="form-label" for="email">Email *</label>
                    <input class="form-control"  id="email" name="email" type="email" value="<?php echo $usuario->getEmail() ?>" disabled>
                </div>

                <div class="col-3">
                    <label class="form-label" for="dni">Dni *</label>
                    <input class="form-control"  id="dni" name="dni" type="text" value="<?php echo $usuario->getDni() ?>" disabled>
                </div>

                <div class="col-3">
                    <label class="form-label" for="genero">Genero *</label>
                    <select id="genero" name="genero" class="form-select" required>
                        <?php if($usuario->getGenero() == 1){ ?>
                            <option value="1" selected>Hombre</option>
                        <?php } else { ?>
                            <option value="1">Hombre</option>
                        <?php } ?>

                        <?php if($usuario->getGenero() == 0){ ?>
                            <option value="0" selected>Mujer</option>
                        <?php } else { ?>
                            <option value="0">Mujer</option>
                        <?php } ?>
                    </select>
                </div>

                <div class="col-3">
                    <label class="form-label" for="nombre">Nombre *</label>
                     <input class="form-control"  id="nombre" name="nombre" type="text" value="<?php echo $usuario->getNombre() ?>" required>
                </div>

                <div class="col-3">
                    <label class="form-label" for="apellido">Apellido *</label>
                    <input class="form-control"  id="apellido" name="apellido" type="text" value="<?php echo $usuario->getApellido() ?>" required>
                </div>

                <div class="col-3">
                    <label class="form-label" for="fecha_nacimiento">Fecha nacimiento *</label>                   
                     <input class="form-control"  id="fecha_nacimiento" name="fecha_nacimiento" type="date" value="<?php echo $usuario->getFechaNacimiento() ?>" required>
                </div>

                <div class="col-3">
                    <label class="form-label" for="telefono">Telefono *</label>                  
                    <input class="form-control" id="telefono" name="telefono" type="number" value="<?php echo $usuario->getTelefono() ?>" required>                
                </div>

                <div class="col-3">
                    <label class="form-label" for="provincia">Provincia *</label>
                    <input class="form-control" id="provincia" name="provincia" type="text" value="<?php echo $usuario->getProvincia() ?>" required>                 
                </div>
                
                <div class="col-3">
                    <label class="form-label" for="municipio">Municipio *</label>
                    <input class="form-control" id="municipio" name="municipio" type="text" value="<?php echo $usuario->getMunicipio() ?>" required>                 
                </div>
                
                <div class="col-3">
                    <label class="form-label" for="direccion">Direccion *</label>
                    <input class="form-control" id="direccion" name="direccion" type="text" value="<?php echo $usuario->getDireccion() ?>" required>              
                </div>
                
                <div class="col-3">
                    <label class="form-label" for="codigo_postal">Codigo postal *</label>  
                    <input class="form-control" id="codigo_postal" name="codigo_postal" type="number" value="<?php echo $usuario->getCodigoPostal() ?>" required>
                </div>
            </div>

            <div class="row mt-3 justify-content-around">
                <div class="col-2">
                    <button class="btn btn-secondary" type="reset">Resetear</button>
                </div>

                <div class="col-2">
                    <input class="btn btn-primary" type="submit" value="Guardar" />
                </div>
            </div>

        </form>

<?php
    }
?>