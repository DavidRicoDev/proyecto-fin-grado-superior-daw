<?php
    // Incluir controladores
    require_once(__DIR__."/../../config/controladores-config.php");

    // Si no existe un usuario en la sesion
    if(empty($_SESSION["usuario"])) {
        // Mostrar la pagina de login
        require_once(__DIR__."/login.php");
    // Si el usuario activo no es de tipo administrador
    } else if ($_SESSION["usuario"]->getTipoUsuario() != "Administrador") {
        // Mostrar la pagina de acceso denegado
        require_once(__DIR__."/plantilla/acceso-denegado.php");
    } else {
        // Crear controlador de usuarios
        $controladorUsuarios = new controladorUsuarios();
        // Obtener usuarios desde base de datos
        $usuarios = $controladorUsuarios->obtenerUsuarios();
?>

        <div class="pt-3 pb-3 col-12 text-center">
            <h4>Listado de usuarios</h4>
        </div>

        <table class="table table-light text-center">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Tipo Usuario</th>
                    <th>Dni</th>
                    <th>Email</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Fecha nacimiento</th>
                    <th>Acciones</th>

                </tr>
            </thead>

            <tbody>
                <?php
                    // Recorrer listado de usuarios
                    foreach($usuarios as $usuario) {
                        // Crear URL para redireccionar a la edicion del usuario
                        $urlEditarUsuario = ".?controlador=usuarios&accion=editar&id=".$usuario->getId();
                ?>

                <tr>
                    <td><?php echo $usuario->getId() ?></td>
                    <td><?php echo $usuario->getTipoUsuario() ?></td>
                    <td><?php echo $usuario->getDni() ?></td>
                    <td><?php echo $usuario->getEmail() ?></td>
                    <td><?php echo $usuario->getNombre() ?></td>
                    <td><?php echo $usuario->getApellido() ?></td>
                    <td><?php echo $usuario->getFechaNacimiento() ?></td>
                    <td>
                        <a class="cursor-pointer icon-pencil pr-2" href="<?php echo $urlEditarUsuario ?>"></a>
                    </td>

                <tr>
                <?php
                    }
                ?>
            </tbody>
        </table>

<?php
    }
?>
