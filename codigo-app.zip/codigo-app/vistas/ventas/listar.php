<?php
    // Incluir controladores
    require_once(__DIR__."/../../config/controladores-config.php");

    // Si no existe un usuario en la sesion
    if(empty($_SESSION["usuario"])) {
        // Mostrar la pagina de login
        require_once(__DIR__."/login.php");
    // Si el usuario activo es de tipo cliente solo puede editar sus propios datos
    } else if ($_SESSION["usuario"]->getTipoUsuario() == "Cliente"
        && !empty($_GET["id"]) && $_GET["id"] != $_SESSION["usuario"]->getId()) {
        // Mostrar la pagina de acceso denegado
        require_once(__DIR__."/../plantilla/acceso-denegado.php");
    } else {
        // Crear controlador de ventas
        $controladorVentas = new ControladorVentas();
        // Obtener ventas desde la base de datos
        $ventas = null;

        // Si la URL contiene el parametro idUsuario
        if (!empty($_GET["idUsuario"])) {
            // Obtener ventas por id de usuario
            $ventas = $controladorVentas->obtenerVentasPorIdUsuario($_GET["idUsuario"]);
        } else {
            // Obtener todas las ventas
            $ventas = $controladorVentas->obtenerVentas();
        }

?>

        <table class="table table-light text-center">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Total productos</th>
                    <th>Precio total</th>
                    <th>Fecha</th>
                    <th>Acciones</th>
                </tr>
            </thead>

            <tbody>
                <?php
                    // Recorrer listado de ventas
                    foreach($ventas as $venta) {
                        // Crear URL para redireccionar a la edicion del venta
                        $urlDetallesVenta = ".?controlador=ventas&accion=editar&id=".$venta->getId();
                ?>
                    <tr>
                        <td><?php echo $venta->getId() ?></td>
                        <td><?php echo $venta->getTotalProductos() ?></td>
                        <td><?php echo $venta->getPrecioTotal() ?></td>
                        <td><?php echo $venta->getFecha() ?></td>
                        <td>
                            <a class="cursor-pointer icon-search pr-2" href="<?php echo $urlDetallesVenta ?>"></a>
                        </td>
                    <tr>
                <?php
                    }
                ?>
            </tbody>  
        </table>

<?php
    }
?>
