<?php
    // Incluir controladores
    require_once(__DIR__."/../../config/controladores-config.php");

    // Crear controlador de ventas
    $controladorVentas = new ControladorVentas();
    // Crear controlador de marcas
    $controladorMarcas = new ControladorMarcas();
    // Crear controlador de categorias
    $controladorCategorias = new ControladorCategorias();

    // Variable que contendra la venta
    $venta = null;
    // Variable que contendra el listado de productos
    $productos = null;
    // Variable que contendra el listado de marcas
    $marcas = null;
    // Variable que contendra el listado de categorias
    $categorias = null;

    if (!empty($_GET["id"])) {
        // Obtenemos el articulo
        $venta = $controladorVentas->obtenerVenta($_GET["id"]);
        // Obtener productos
        $productos = $controladorVentas->obtenerProductosVenta($venta->getId());
        // Obtener marcas
        $marcas = $controladorMarcas->obtenerMarcas();
        // Obtener categorias
        $categorias = $controladorCategorias->obtenerCategorias();
}

?>

<div class="row pb-4">
    <div class="col-3">
        <label class="form-label"  for="id">Id</label>
        <input class="form-control" id="id" name="id" type="text" value="<?php echo $venta->getId() ?>" disabled>
    </div>

    <div class="col-3">
        <label class="form-label"  for="total_productos">Total productos</label>
        <input class="form-control" id="total_productos" name="total_productos" type="text" value="<?php echo $venta->getTotalProductos() ?>" disabled>
    </div>

    <div class="col-3">
        <label class="form-label"  for="precio_total">Precio total</label>
        <input class="form-control" id="precio_total" name="precio_total" type="text" value="<?php echo $venta->getPrecioTotal() ?> €" disabled>
    </div>

    <div class="col-3">
        <label class="form-label"  for="fecha">Fecha</label>
        <input class="form-control" id="fecha" name="fecha" type="text" value="<?php echo $venta->getFecha() ?>" disabled>
    </div>

    <div class="col-12">
    <table class="table table-light text-center">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Categoria</th>
                    <th>Marca</th>
                    <th>Nombre</th>
                    <th>Precio</th>
                </tr>
            </thead>

            <tbody>
                <?php
                    // Recorrer listado de productos
                    foreach($productos as $producto) {
                        // Crear URL para redireccionar a la edicion del producto
                        $urlEditarProducto = ".?controlador=productos&accion=editar&id=".$producto->getId();
                ?>
                    <tr>
                        <td><?php echo $producto->getId() ?></td>
                        <?php   
                            // Recorrer listado de categorias
                            foreach($categorias as $categoria){
                                // Si el id de la categoria coincide con el id de la categoria a la que pertenece el producto actual
                                if($producto->getCategoria() == $categoria->getId()){
                        ?>
                                    <td><?php echo $categoria->getNombre() ?></td>
                        <?php  
                                }
                            }
                        ?>
                        <?php   
                            // Recorrer listado de marcas
                            foreach($marcas as $marca){
                                // Si el id de la marca coincide con el id de la marca a la que pertenece el producto actual
                                if($producto->getMarca() == $marca->getId()){
                        ?>
                                    <td><?php echo $marca->getNombre() ?></td>
                        <?php  
                                }
                            }
                        ?>
                          
                        
                        <td><?php echo $producto->getNombre() ?></td>
                        <td><?php echo $producto->getPrecio() ?></td>
                    <tr>
                <?php
                    }
                ?>
            </tbody>
        </table>

    </div>
</div>