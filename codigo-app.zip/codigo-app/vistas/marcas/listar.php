<?php
    // Incluir controladores
    require_once(__DIR__."/../../config/controladores-config.php");

    // Si no existe un usuario en la sesion
    if(empty($_SESSION["usuario"])) {
        // Mostrar la pagina de login
        require_once(__DIR__."/login.php");
    // Si el usuario activo no es de tipo administrador
    } else if ($_SESSION["usuario"]->getTipoUsuario() != "Administrador") {
        // Mostrar la pagina de acceso denegado
        require_once(__DIR__."/plantilla/acceso-denegado.php");
    } else {
        // Crear controlador de marcas
        $controladorMarcas = new ControladorMarcas();
        // Obtener marcas desde la base de datos
        $marcas = $controladorMarcas->obtenerMarcas();
?>

        <a href=".?controlador=marcas&accion=editar" id="crear" name="crear" class="mb-2 mt-2 btn btn-primary" style="float: inline-end">Crear marca</a>

        <div class="pt-3 pb-3 col-12 text-center">
            <h4>Listado de marcas</h4>
        </div>
        
        <table class="table table-light text-center">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Acciones</th>
                </tr>
            </thead>

            <tbody>
                <?php
                    // Recorrer listado de marcas
                    foreach($marcas as $marca) {
                        // Crear URL para redireccionar a la edicion del marca
                        $urlEditarMarca = ".?controlador=marcas&accion=editar&id=".$marca->getId();
                ?>
                    <tr>
                        <td><?php echo $marca->getId() ?></td>
                        <td><?php echo $marca->getNombre() ?></td>
                        <td><?php echo $marca->getEmail() ?></td>
                        <td>
                            <a class="cursor-pointer icon-pencil pr-2" href="<?php echo $urlEditarMarca ?>"></a>
                        </td>
                    <tr>
                <?php
                    }
                ?>
            </tbody>    
        </table>

<?php
   }
?>