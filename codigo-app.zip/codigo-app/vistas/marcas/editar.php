<?php
    // Incluir controladores
    require_once(__DIR__."/../../config/controladores-config.php");

    // Si no existe un usuario en la sesion
    if(empty($_SESSION["usuario"])) {
        // Mostrar la pagina de login
        require_once(__DIR__."/../login.php");
    // Si el usuario activo es de tipo cliente no puede registrar nuevas marcas
    } else if ($_SESSION["usuario"]->getTipoUsuario() != "Administrador") {
        // Mostrar la pagina de acceso denegado
        require_once(__DIR__."/../plantilla/acceso-denegado.php");
    } else {
        // Crear controlador de marcas
        $controladorMarcas = new controladorMarcas();
        // Crear objeto que se almacenará en base de datos
        $marca = null;

        // Si aparece el parametro id en la URL significa que es una edicion
        if (!empty($_GET["id"])) {
            // Obtenemos la marca
            $marca = $controladorMarcas->obtenerMarca($_GET["id"]);
        }

        // Comprobar si hemos llegado a través del método POST
        if (!empty($_POST)) {
            //Comprobar que se han enviado todos los datos NO NULOS del formulario
            if (!empty($_POST["nombre"]) && !empty($_POST["email"])) {
                // Obtener datos desde formulario
                $nombre = $_POST["nombre"];
                $email = $_POST["email"];

                try{
                    // Si la marca es distinta de null significa que es una actualizacion
                    if ($marca != null) {
                        // Actualizar marca en base de datos
                        $marca = $controladorMarcas->actualizarMarca(new Marca($marca->getId(), $nombre, $email));
                        // Mostramos el mensaje de marca actualizada
                        echo "
                            <div class='alert alert-success' role='alert'>
                                Marca actualizada correctamente.
                            </div>";
                    // Si la marca es null significa que es una insercion
                    } else {
                        // Crear marca en base de datos
                        $marca = $controladorMarcas->guardarMarca(new Marca(null, $nombre, $email));
                        // Mostramos el mensaje de marca creado
                        echo "
                            <div class='alert alert-success' role='alert'>
                                Marca creada correctamente.
                            </div>";
                    }
                // Controlar excepciones
                } catch (Exception $e) {
                    echo "
                        <div class='alert alert-danger' role='alert'>
                            ".$e->getMessage()."
                        </div>";
                }
            }
        
        }
    
?>

        <div class="container">

            <div class="pt-3 col-12 text-center">
                <?php if(!empty($marca)){ ?>
                    <h4>Editar marca</h4>
                <?php } else { ?>
                    <h4>Crear marca</h4>
                <?php } ?>
            </div>

            <form id="formularioMarca" name="formularioMarca" method="POST" class="pb-3">

                <div class="row mt-2">

                    <?php if(!empty($marca)){ ?>
                        <div class="col-4">
                            <label class="form-label" for="id">Id</label>
                            <input class="form-control" id="id" name="id" type="text" value="<?php echo $marca->getId() ?>" disabled>
                        </div>
                    <?php } ?>

                    <div class="col-4">
                        <label class="form-label" for="nombre">Nombre</label>
                        <?php if(!empty($marca)){ ?>
                            <input class="form-control" id="nombre" name="nombre" type="text" value="<?php echo $marca->getNombre() ?>" required>
                        <?php } else { ?>
                            <input class="form-control" id="nombre" name="nombre" type="text" required> 
                        <?php } ?>
                    </div>

                    <div class="col-4">
                        <label class="form-label" for="email">Email</label>
                        <?php if(!empty($marca)){ ?>
                            <input class="form-control" id="email" name="email" type="email" value="<?php echo $marca->getEmail() ?>" required>
                        <?php } else { ?>
                            <input class="form-control" id="email" name="email" type="email" required> 
                        <?php } ?>
                    </div>

                </div>

                <div class="row mt-3 justify-content-around">
                    <div class="col-2">
                        <button class="btn btn-secondary" type="reset">Resetear</button>
                    </div>

                    <div class="col-2">
                        <input class="btn btn-primary" type="submit" value="Guardar" />
                    </div>
                </div>

            </form>
        </div>

<?php
    }
?>