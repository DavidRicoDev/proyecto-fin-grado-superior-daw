<?php
    // Incluir controladores
    require_once(__DIR__."/../../config/controladores-config.php");

    // Si no existe un usuario en la sesion
    if(empty($_SESSION["usuario"])) {
        // Mostrar la pagina de login
        require_once(__DIR__."/../login.php");
    // Si el usuario activo es de tipo cliente no puede registrar nuevos productos
    } else if ($_SESSION["usuario"]->getTipoUsuario() != "Administrador") {
        // Mostrar la pagina de acceso denegado
        require_once(__DIR__."/../plantilla/acceso-denegado.php");
    } else {
        // Crear controlador de productos
        $controladorProductos = new ControladorProductos();
        // Crear controlador de marcas
        $controladorMarcas = new ControladorMarcas();
        // Crear controlador de categorias
        $controladorCategorias = new ControladorCategorias();

        // Obtener marcas
        $marcas = $controladorMarcas->obtenerMarcas();
        // Obtener categorias
        $categorias = $controladorCategorias->obtenerCategorias();
        // Crear objeto que se almacenará en base de datos
        $producto = null;

        // Si aparece el parametro id en la URL significa que es una edicion
        if (!empty($_GET["id"])) {
            // Obtenemos el producto
            $producto = $controladorProductos->obtenerProducto($_GET["id"]);
        }

        // Comprobar si hemos llegado a través del método POST
        if (!empty($_POST)) {
            //Comprobar que se han enviado todos los datos NO NULOS del formulario
            if (!empty($_POST["categoria"]) 
                && !empty($_POST["marca"])  
                && !empty($_POST["nombre"]) 
                && !empty($_POST["stock"])  
                && !empty($_POST["precio"])) {
                // Obtener datos desde formulario
                $categoria = $_POST["categoria"];
                $marca = $_POST["marca"];
                $nombre = $_POST["nombre"];
                $stock = $_POST["stock"];
                $precio = $_POST["precio"];
    
                try{
                    // Si el producto es distinto de null significa que es una actualizacion
                    if($producto != null){
                        // Actualizar producto en base de datos
                        $producto = $controladorProductos->actualizarProducto(new Producto($producto->getId(), $nombre, $categoria, $marca,  null, $precio, $stock));
                        // Mostramos el mensaje de producto actualizado
                        echo "
                            <div class='alert alert-success' role='alert'>
                                Producto actualizado correctamente.
                            </div>";
                    // Si el producto es null significa que es una insercion
                    } else {
                        // Crear producto en base de datos
                        $producto = $controladorProductos->guardarProducto(new Producto(null, $nombre, $categoria, $marca, null, $precio, $stock));
                        // Mostramos el mensaje de producto creado
                        echo "
                            <div class='alert alert-success' role='alert'>
                                Producto creado correctamente.
                            </div>";
                    }
                // Controlar excepciones                
                } catch (Exception $e) {
                    echo "
                        <div class='alert alert-danger' role='alert'>
                            ".$e->getMessage()."
                        </div>";
                }
            }
        
        } 
?>

        <div class="container">

            <div class="pt-3 col-12 text-center">
                <?php if(!empty($producto)){ ?>
                    <h4>Editar producto</h4>
                <?php } else { ?>
                    <h4>Crear producto</h4>
                <?php } ?>
            </div>

            <form id="formularioProducto" name="formularioProducto" method="POST" class="pb-3">

                <div class="row mt-2">

                    <?php if(!empty($producto)){ ?>
                        <div class="col-3">
                            <label class="form-label" for="id">Id</label>
                            <input class="form-control" id="id" name="id" type="text" value="<?php echo $producto->getId() ?>" disabled>
                        </div>
                    <?php } ?>

                    <div class="col-3">
                        <label class="form-label" for="categoria">Categoria</label>
                        <?php if(!empty($producto)){ ?>
                            <select id="categoria" name="categoria" class="form-select" required>
                                <?php
                                    foreach($categorias as $categoria) {                        
                                        if($categoria->getId() == $producto->getCategoria()) {
                                ?>
                                            <option value="<?php echo $categoria->getId() ?>" selected><?php echo $categoria->getNombre() ?></option>                    
                                        <?php } else { ?>                        
                                            <option value="<?php echo $categoria->getId() ?>"><?php echo $categoria->getNombre() ?></option>
                                        <?php } ?>
                                <?php
                                    }
                                ?>
                            </select>
                        <?php } else { ?>
                            <select id="categoria" name="categoria" class="form-select" required>
                                <option selected></option>
                                <?php
                                    // Recorrer listado de categorias
                                    foreach($categorias as $categoria) {
                                ?>
                                    <option value="<?php echo $categoria->getId() ?>"><?php echo $categoria->getNombre() ?></option>
                                <?php
                                    }
                                ?>
                            </select>
                        <?php } ?>
                    </div>

                    <div class="col-3">
                        <label class="form-label" for="marca">Marca</label>
                        <?php if(!empty($producto)){ ?>
                            <select id="marca" name="marca" class="form-select" required>
                                <?php
                                    // Recorrer listado de marcas
                                    foreach($marcas as $marca) {             
                                        // Si el id de la marca coincide con el id de la marca a la que pertenece el producto actual           
                                        if($marca->getId() == $producto->getMarca()) {
                                ?>
                                            <option value="<?php echo $marca->getId() ?>" selected><?php echo $marca->getNombre() ?></option>                    
                                        <?php } else { ?>                        
                                            <option value="<?php echo $marca->getId() ?>"><?php echo $marca->getNombre() ?></option>
                                        <?php } ?>
                                <?php
                                    }
                                ?>
                            </select>
                        <?php } else { ?>
                            <select id="marca" name="marca" class="form-select" required>
                                <option selected></option>
                                <?php
                                    // Recorrer listado de marcas
                                    foreach($marcas as $marca) {
                                ?>
                                    <option value="<?php echo $marca->getId() ?>"><?php echo $marca->getNombre() ?></option>
                                <?php
                                    }
                                ?>
                            </select>
                        <?php } ?>
                    </div>

                    <div class="col-3">
                            <label class="form-label" for="nombre">Nombre</label>
                        <?php if(!empty($producto)){ ?>
                            <input class="form-control"  id="nombre" name="nombre" type="text" value="<?php echo $producto->getNombre() ?>" required>
                        <?php } else { ?>
                            <input class="form-control"  id="nombre" name="nombre" type="text" required>
                        <?php } ?>
                    </div>

                    <div class="col-3">
                            <label class="form-label" for="nombre">Stock</label>
                        <?php if(!empty($producto)){ ?>
                            <input class="form-control"  id="stock" name="stock" type="number" value="<?php echo $producto->getStock() ?>" required>
                        <?php } else { ?>
                            <input class="form-control"  id="stock" name="stock" type="number" required>
                        <?php } ?>
                    </div>

                    <div class="col-3">
                            <label class="form-label" for="imagen">Imagen</label>
                        <?php if(!empty($producto)){ ?>
                            <input class="form-control"  id="imagen" name="imagen" type="img" value="<?php echo $producto->getImagen() ?>">
                        <?php } else { ?>
                            <input class="form-control"  id="imagen" name="imagen" type="img" required>
                        <?php } ?>
                    </div>

                    <div class="col-3">
                        <label class="form-label" for="precio">Precio</label>
                    <?php if(!empty($producto)){ ?>
                        <input class="form-control"  id="precio" name="precio" type="number" value="<?php echo $producto->getPrecio() ?>" required>
                    <?php } else { ?>
                        <input class="form-control"  id="precio" name="precio" type="number" required>
                        <?php } ?>
                    </div>
                </div>

                <div class="row mt-3 justify-content-around">
                    <div class="col-2">
                        <button class="btn btn-secondary" type="reset">Resetear</button>
                    </div>

                    <div class="col-2">
                        <input class="btn btn-primary" type="submit" value="Guardar" />
                    </div>
                </div>

            </form>
        </div>

<?php
    }
?>