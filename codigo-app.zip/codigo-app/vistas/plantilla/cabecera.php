<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
	<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
</head>
<body>
	<div class="container">
		<div class="row">
			<header>
				<img src="./../../img/cabecera.jpg" class="img-fluid" alt="...">
				<div class="mt-1 pb-2 text-center rounded bg-light">
					<h1>Sport Project</h1>
					
					<?php 
						// Si existe un usuario en la sesion y es de tipo cliente
						if(!empty($_SESSION["usuario"]) && $_SESSION["usuario"]->getTipoUsuario() == "Cliente") {
							$urlPerfilUsuario = ".?controlador=usuarios&accion=editar&id=".$_SESSION["usuario"]->getId();
							$urlPedidosUsuario = ".?controlador=ventas&accion=listar&idUsuario=".$_SESSION["usuario"]->getId();
					?>
							<div class="row">
								<div class="col">
									<a href="/" class="text-dark" style="text-decoration: none"><h4>Principal    <i class="icon-home" style="color: blue"></i></h4></a>
								</div>
								<div class="col">
									<a href="<?php echo $urlPedidosUsuario ?>" class="text-dark" style="text-decoration: none"><h4>Mis pedidos    <i class="icon-shopping-cart" style="color: blue"></i></h4></a>
								</div>
								<div class="col">
									<a href="<?php echo $urlPerfilUsuario ?>" class="text-dark" style="text-decoration: none"><h4>Perfil de <?php echo $_SESSION["usuario"]->getNombre() ?>  <i class="icon-user" style="color: blue"></i></h4></a>
								</div>
								<div class="col">
									<a href=".?controlador=logout" class="text-dark" style="text-decoration: none"><h4>Logout    <i class="icon-off" style="color: red"></i></h4></a>
								</div>
							</div>
					<?php
						// Si existe un usuario en la sesion y es de tipo administrador
						} else if(!empty($_SESSION["usuario"]) && $_SESSION["usuario"]->getTipoUsuario() == "Administrador") { 
					?>
							<div class="row">
								<div class="col">
									<a href=".?controlador=ventas&accion=listar" class="text-dark" style="text-decoration: none"><h4>Ventas    <i class="icon-shopping-cart" style="color: blue"></i></h4></a>
								</div>
								<div class="col">
									<a href=".?controlador=usuarios&accion=listar" class="text-dark" style="text-decoration: none"><h4>Usuarios    <i class="icon-user" style="color: blue"></i></h4></a>
								</div>
								<div class="col">
									<a href=".?controlador=marcas&accion=listar" class="text-dark" style="text-decoration: none"><h4>Marcas    <i class="icon-tag" style="color: blue"></i></h4></a>
								</div>
								<div class="col">
									<a href=".?controlador=productos&accion=listar" class="text-dark" style="text-decoration: none"><h4>Productos    <i class="icon-list-alt" style="color: blue"></i></h4></a>
								</div>
								<div class="col">
									<a href=".?controlador=logout" class="text-dark" style="text-decoration: none"><h4>Logout    <i class="icon-off" style="color: red"></i></h4></a>
								</div>
							</div>
					<?php
						}
					?>
				</div>
			</header>
		</div>
