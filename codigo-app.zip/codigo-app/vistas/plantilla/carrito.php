<?php

    require_once(__DIR__."/../../config/controladores-config.php");
    // Crear controlador de carrito
    $controladorCarrito = new ControladorCarrito();
    // Crear controlador de ventas
    $controladorVentas = new ControladorVentas();

    // Si existe un objeto carrito en la sesion y no contiene productos
    if(empty($_SESSION["carrito"]) || $_SESSION["carrito"]->obtenerTotalProductos() == 0) {
?>

        <h3><i class="icon-shopping-cart pr-2" style="margin-right: 1rem;color: blue;"></i>Carrito</h3>
        <h4>Aún no se ha agregado ningún producto al carrito.</h4>

<?php   
    // Si existe un objeto carrito en la sesion y contiene productos
    } else { 
        // Si el POST indica que se hizo click en un boton de finalizar compra
        if (isset($_POST["finalizar"])) {
            try{
                // Finalizar venta
                $resultado = $controladorVentas->finalizarVenta($_SESSION["usuario"]->getId(), $controladorCarrito->obtenerCarrito());
                if($resultado == true){
                    $controladorCarrito->limpiarCarrito();
                    // Refrescar pagina actual
                    header("Location: .?compra=finalizada");
                    exit();
                } else {
                    // Mostramos el mensaje de error al finalizar la compra
                    echo "
                        <div class='alert alert-danger' role='alert'>
                            Se produjo un error al finalizar la compra
                        </div>";
                }
            } catch (Exception $e) {
                echo "
                    <div class='alert alert-danger' role='alert'>
                        ".$e->getMessage()."
                    </div>";
            }
        }
?>
        <h3><i class="icon-shopping-cart pr-2" style="margin-right: 1rem;color: blue;"></i>Carrito</h3>
        
        <form id="formularioCarrito" name="formularioCarrito" method="POST">
            <?php
                // Recorrer productos del carrito
                foreach($controladorCarrito->obtenerProductos() as $producto) {
                    // Si el POST indica que se hizo click en un boton de eliminar producto del carrito
                    if (isset($_POST["button-".$producto->getId()])) {
                        // Eliminar producto del carrito
                        $controladorCarrito->eliminarProducto($producto);
                        // Refrescar pagina actual                        
                        header("Location: .");
                        exit();
                    }
            ?>

                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $producto->getNombre() ?></h5>    
                        <p class="card-text">Precio: <?php echo $producto->getPrecio() ?> €</p>
                    </div>

                    <div class="container-fluid text-center pb-4">
                        <input type="submit" id="<?php echo "button-".$producto->getId() ?>" name="<?php echo "button-".$producto->getId() ?>" class="btn btn-danger" value="Eliminar"></input>
                    </div>
                </div>

            <?php   
                }
            ?>

            <h5>Productos: <?php echo $controladorCarrito->obtenerTotalProductos() ?></h5>
            <h5>Total: <?php echo $controladorCarrito->obtenerPrecioTotal() ?> €</h5>
            
            <div class="container-fluid text-center pb-4">
                    <input type="submit" id="finalizar" name="finalizar" class="btn btn-success" value="Comprar"></input>
            </div>
        </form>
<?php   
    }
?>