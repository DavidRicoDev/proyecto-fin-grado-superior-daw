<div class="mt-1 text-center">
    <img src="./../../img/acceso-denegado.jpg" class="img-fluid text-center" alt="...">
    <h2>No dispone de los permisos necesarios para acceder al contenido.</h2>
    <a href="/">Volver a la página principal</a>
</div>