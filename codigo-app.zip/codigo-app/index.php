<?php 

// Incluir controladores
require_once(__DIR__."/config/controladores-config.php");
// Iniciar sesion
session_start();
// Incluir cabecera de pagina
require_once(__DIR__."/vistas/plantilla/cabecera.php");

// Si no existe un usuario en la sesion
if(empty($_SESSION["usuario"])) {
    // Mostrar la pagina de login
    require_once(__DIR__."/vistas/login.php");
// Si en la URL aparece el parametro controlador y tiene el valor logout
} else if(!empty($_GET["controlador"]) && $_GET["controlador"] == "logout"){
    // Limpiamos el usuario y el carrito de la sesion
    $_SESSION["usuario"] = null;
    $_SESSION["carrito"] = null;
    // Redireccion a la pagina principal
    header("Location: .");
    exit();
} else {
?>
    <?php
        // Si en la URL aparece el parametro compra y tiene el valor finalizada
        if(!empty($_GET["compra"]) && $_GET["compra"] == "finalizada") {
            // Mostramos el mensaje de compra finalizada
            echo "
                <div class='alert alert-success text-center mt-3' role='alert'>
                    Compra realizada correctamente. En unos días recibirá sus productos en casa!! Gracias por confiar en SportProject.
                </div>";
        }
    ?>

    <div class="row mt-3">

        <?php 
            // Si el usuario activo es de tipo cliente mostramos el carrito de compra que ocupara 2 columnas
            if($_SESSION["usuario"]->getTipoUsuario() == "Cliente") { 
        ?>
                <div class="col-2">
                    <div class="container-fluid pt-2 pb-2 rounded bg-light">
                        <?php require_once(__DIR__."/vistas/plantilla/carrito.php"); ?>
                    </div>
                </div>
        <?php 
            }
        ?>

        <?php          
            // Si el usuario activo es de tipo cliente el panel principal ocupara 10 columnas
            if($_SESSION["usuario"]->getTipoUsuario() == "Cliente") {
        ?>
                <div class="col-10 rounded bg-light">
        <?php 
            // Si el usuario activo es de tipo cliente el panel principal ocupara 12 columnas
            } else if ($_SESSION["usuario"]->getTipoUsuario() == "Administrador") {
        ?>
                <div class="col-12 rounded bg-light">
        <?php 
            }
        ?>

            <?php 
                // Si en la URL no aparece el parametro controlador
                if(empty($_GET["controlador"])){
                    // Si el usuario activo es de tipo administrador
                    if($_SESSION["usuario"]->getTipoUsuario() == "Administrador") {
                        // Incluir la vista listado de ventas
                        require_once(__DIR__."/vistas/ventas/listar.php");
                    // Si el usuario activo es de tipo cliente
                    } else {
                        // Incluir la vista principal
                        require_once(__DIR__."/vistas/principal.php");
                    }
                // Si en la URL aparece el parametro controlador
                } else if (!empty($_GET["controlador"])) {
                 
                    // Si en la URL no aparece el parametro accion y tiene valor listar
                    if(empty($_GET["accion"]) || $_GET["accion"] == "listar") {
                        // Incluir vista listar del controlador indicado
                        require_once(__DIR__."/vistas/".$_GET["controlador"]."/listar.php");
                    // Si en la URL no aparece el parametro accion y tiene valor editar
                    } else if ($_GET["accion"] == "editar") {
                        // Incluir vista editar del controlador indicado
                        require_once(__DIR__."/vistas/".$_GET["controlador"]."/editar.php");
                    }
                }                
            ?>
        </div>
    </div>

<?php 
}
// Incluir pie de pagina
require_once(__DIR__."/vistas/plantilla/pie.php");
?>